The two versions in the zip folder are:

svf.f90

-> the original source code

Calculates the weighting using the number of rings. The weighting does not depend on the field of view.  




svf.f90    

-> a modified version:
Changes have been done to the weighting function:

The new version calculates the weighting for 90 rings. It then uses only the weighting of the first rings according to the field of view.
E.g. 75 rings for 150 degrees. 75 rings are then used to analyse the picture.

However, these changes are specially implemented for our pictures (our resolution and our FOV). The part where you can choose the FOV is
not removed from the programme but is not working anymore/might produce erroneous results for other field of views and resolution.
If the source code is not carefully adapted it might produce erroneous results. This is still work in progress.

