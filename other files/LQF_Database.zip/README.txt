This directory contains an archive of the database files used for LQF (http://urban-climate.net/umep/LQF_Manual#International_database). 

Versions:
v1.1 21 Mar 2017: 
 * Initial version after in-house corrections. Matches LUCY input data as far as possible, with minor revisions to correct inconsistencies.
v1.2 08 Aug 2017: 
 * China split into province-specific values to improve building emissions representation
 * kwh_year updated for many countries to use (Total Final Energy Consumption minus transport fuel) [IEA 2016 headline energy demand data] instead of total national primary consumption from the same dataset (See Gabey et al., 2017 - Submitted)
