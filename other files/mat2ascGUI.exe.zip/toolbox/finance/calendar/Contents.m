% Financial Toolbox calendar functions.
%
